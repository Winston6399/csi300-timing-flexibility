"""Rebuild the early CSI 300 deletions from CSI's public announcement bodies.

Run with Python 3.10+ and python-calamine (XLS/XLSX reader):
    python fetch_event_history.py

Dates are the final trading session of the old portfolio. For notices effective
on Monday morning, use the preceding trading day. In June 2016 June 9-10
were exchange holidays; the final old session was Wednesday, June 8:
https://www.sse.com.cn/disclosure/dealinstruc/closed/list/c/c_20160104_4028872.shtml
Friday after-close
notices already specify the last old session. Each mapped date and the number
of departures are checked against the notice text before the CSV is replaced.
"""

import argparse
import csv
import html
import io
import json
import re
import time
from pathlib import Path
from urllib.request import urlopen


ROOT = Path(__file__).resolve().parent
DIRECT = "https://www.csindex.com.cn/csindex-home/announcement/queryAnnouncementById?id="
# (notice ID, final old session, effective-date text fragment)
NOTICES = [
    (2723, "2013-06-28", "2013年7月1日调整"),
    (6750, "2013-12-13", "2013年12月16日调整"),
    (3670, "2014-06-13", "2014年6月16日调整"),
    (3596, "2014-12-12", "2014年12月15日调整"),
    (4084, "2015-06-12", "2015年6月15日调整"),
    (4272, "2015-12-11", "2015年12月14日调整"),
    (3855, "2016-06-08", "2016年6月13日调整"),
    (4003, "2016-12-09", "2016年12月12日调整"),
    (12583, "2017-06-09", "2017年6月12日调整"),
    (12590, "2017-12-08", "2017年12月11日调整"),
    (11518, "2018-06-08", "2018年6月11日调整"),
    (11859, "2018-12-14", "2018年12月17日调整"),
    (11379, "2019-06-14", "2019年6月17日调整"),
    (11529, "2019-12-13", "2019年12月16日调整"),
    (11429, "2020-06-12", "2020年6月15日调整"),
    (11514, "2020-12-11", "2020年12月14日调整"),
    (12470, "2021-06-11", "2021年6月11日收盘后"),
    (13888, "2021-12-10", "2021年12月10日收市后"),
    (14223, "2022-06-10", "2022年6月10日收市后"),
    (14497, "2022-12-09", "2022年12月9日收市后"),
]
HEADER = ("notice_date", "last_old_session", "code", "name", "source_url", "date_source_url")


def visible(fragment):
    plain = html.unescape(re.sub(r"<[^>]+>", " ", fragment))
    return re.sub(r"\s+", "", plain)


def attachment_rows(body, cache):
    from python_calamine import CalamineWorkbook

    urls = re.findall(r'href="(https://oss-ch\.csindex\.com\.cn/[^"]+\.xlsx?)"', html.unescape(body))
    if len(urls) != 1:
        raise ValueError(f"Expected one official Excel attachment, found {urls}")
    url = urls[0]
    cached = cache / ("codex-csi-verified-" + url.rsplit("/", 1)[-1]) if cache else None
    if cached and cached.exists():
        payload = cached.read_bytes()
    else:
        with urlopen(url, timeout=150) as response:
            payload = response.read()
    book = CalamineWorkbook.from_filelike(io.BytesIO(payload))
    sheet = book.get_sheet_by_name("调出").to_python()
    if sheet[0][:4] != ["指数代码", "指数简称", "证券代码", "证券简称"]:
        raise ValueError(f"Unexpected deletion sheet header: {sheet[0]}")
    return url, [(str(row[2]).zfill(6), row[3]) for row in sheet[1:] if row[0] == "000300" and row[1] == "沪深300"]


def parse_notice(notice_id, last_old, effective_text, cache=None):
    url = DIRECT + str(notice_id)
    with urlopen(url, timeout=40) as response:
        data = json.load(response)["data"]
    body = data["content"]
    full_text = visible(body)
    if effective_text not in full_text:
        raise ValueError(f"{notice_id}: verify the effective date again")
    announced = int(re.search(r"沪深300指数更换(\d+)只", full_text)[1])
    heading = re.search(r"沪深\s*300\s*指数样本(?:股)?调整名单", html.unescape(body), re.I)
    if heading:
        source = url
        deletions = html_deletions(body[heading.end():])
    else:
        source, deletions = attachment_rows(body, cache)
    result = [(data["publishDate"], last_old, code, name, source, url) for code, name in deletions]
    if len(result) != announced or len({r[2] for r in result}) != announced:
        raise ValueError(f"{notice_id}: {len(result)} rows, {announced} announced")
    return result


def html_deletions(after_heading):
    table = re.search(r"<table\b.*?</table>", after_heading, re.I | re.S)[0]
    table_text = visible(table)
    if not ("调出名单调入名单" in table_text and table_text.index("调出") < table_text.index("调入")):
        raise ValueError("Unexpected column order")
    result = []
    # Earlier CSI source HTML omits the optional </tr> before the next <tr>.
    for row in re.split(r"<tr\b[^>]*>", table, flags=re.I)[1:]:
        cells = [visible(cell) for cell in re.findall(r"<t[dh]\b[^>]*>(.*?)</t[dh]>", row, re.I | re.S)]
        if len(cells) == 4 and re.fullmatch(r"\d{6}", cells[0]):
            if not re.fullmatch(r"\d{6}", cells[2]) or not cells[1]:
                raise ValueError("Malformed table row")
            result.append((cells[0], cells[1]))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attachment-cache", type=Path, help="Read previously downloaded official workbooks.")
    args = parser.parse_args()
    records = []
    for notice in NOTICES:
        rows = parse_notice(*notice, cache=args.attachment_cache)
        records.extend(rows)
        print(rows[0][0], rows[0][1], len(rows), "matched", flush=True)
        time.sleep(.7)
    target = ROOT / "events.csv"
    temp = target.with_suffix(".csv.tmp")
    with temp.open("w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out, lineterminator="\n")
        writer.writerow(HEADER)
        writer.writerows(sorted(records))
    temp.replace(target)


if __name__ == "__main__":
    main()
