# Paired timing experiment

D is the last trading session under the old index composition. Days are real
sessions from the CSI 300 cash index bars listed in data_manifest.csv. Each deleted stock is a separate
counterfactual account starting with CNY 10,000. The individual accounts do not
compose a jointly tradable portfolio.

* All arms have identical initial cash, number of shares and terminal valuation
  date. Quantity is set after the D close, assuming a 25% purchase-price buffer.
  Ordinary orders are rounded down to 100-share lots. STAR orders require at
  least 200 shares and then permit whole-share increments.
* Fixed buys at the D+1 open. Flexible waits until D+2 if D close is strictly
  below the D-1 close, and otherwise buys at the D+1 open. Always-wait buys at
  the D+2 open regardless of the signal. No information after D selects the
  planned entry. Both subsequent opening prices are observed only for execution.
* Mark all arms at D+5 close on unadjusted daily bars without liquidation.
  Unspent cash earns zero; dividends and price adjustments are addressed by
  excluding flagged corporate-action windows. A common terminal sale fee would
  cancel for equal quantities when both arms fill, but would affect unmatched
  fills. The experiment is a comparison of net marked wealth at this horizon.
* Zero costs assumes all purchases at the open and no commission. Base uses
  buy commission 3 bp with a CNY 5 minimum and 5 bp adverse slippage. Stress
  uses 5 bp with the same minimum and 20 bp slippage. These are hypothetical
  costs; no assumption about the user's broker or access to the opening price.
* A budget breach, insufficient size or a buy order opening at the assumed upper
  price limit leaves the relevant arm in cash. A 0.01 CNY tick rounds the limit
  to nearest cent, half up. Board/date and announcement name determine the
  rate (ST name for main board); exact historical price limits and queue fills
  are unavailable here. This proxy is conservative for stocks that open at
  the limit and subsequently trade below it.
* If any daily bar or positive price/volume is absent on D-1 through D+5,
  the event is excluded; a missing bar alone does not identify a suspension.
  Tencent corporate-action markers (and optional independent action dates) on
  D through D+5 exclude the event. Missing markers do not prove the absence
  of a distribution. See exclusions.csv for the individual cases. Events with
  too little capital to trade any shares remain in the account-level comparison.
* Results in CNY per CNY 10,000 are numerically equal to basis points of initial
  wealth. The one-row-per-pair file reports all three costs. Each batch first
  averages pairs. The principal summary equally weights reconstitution batches;
  equal-pair summaries are also shown. Percentile intervals resample whole
  batches with replacement, 5,000 draws, seed 21439. With fewer than five
  batches no interval is printed. Even with more batches the bootstrap is
  descriptive and limited by market dependence. June 2025 and December 2025
  are separate pre-inspected cohorts excluded from other_batches. Historical
  data not used to set this rule are not a prospective test.
* market_control.csv, base-cost events only: scale the concurrent CSI 300 ETF
  (510300) D+1-to-D+2 open difference by the target's matched D-close notional
  divided by the ETF D close, allowing fractional ETF units for the diagnostic.
  Subtract this market component once for always-wait and on wait signals for
  flexible. Stocks unfilled on both dates have zero exposure; unmatched fills are
  excluded from this diagnostic. The ETF component uses raw prices without
  transaction costs. A beta of one is assumed. This comparison cannot isolate
  index flows from industry shocks, stock selection or individual stock betas.
