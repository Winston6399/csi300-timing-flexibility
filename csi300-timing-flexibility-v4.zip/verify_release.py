"""Offline consistency checks on the released event-level results and manifests."""
from collections import defaultdict
import csv
from pathlib import Path
from statistics import fmean

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def check(ok, msg):
    if not ok:
        raise ValueError(msg)


def close(a, b, message, tol=0.00011):
    check(abs(float(a) - float(b)) <= tol, message)


def key(r):
    return (r["last_old_session"], r["code"])


def main():
    events = rows(ROOT / "events.csv") + rows(ROOT / "events_recent.csv")
    ids = set(map(key, events))
    check(len(events) == len(ids), "Duplicate events")
    for r in events:
        check(r["notice_date"] < r["last_old_session"], "Notice not strictly before event")
    base = [r for r in rows(OUT / "pairs.csv") if r["cost"] == "base"]
    ex = rows(OUT / "exclusions.csv")
    accepted = set(map(key, base))
    check(len(base) == len(accepted) and not accepted.intersection(map(key, ex)), "Overlap")
    check(ids == accepted.union(map(key, ex)) and len(ex) == len(ids)-len(accepted), "Missing IDs")
    metrics = {"flex_minus_fixed": ("flex", "fixed"), "wait_minus_fixed": ("always_wait","fixed"),
               "flex_minus_wait": ("flex","always_wait")}
    for r in base:
        for m, (a, b) in metrics.items():
            close(r[m], float(r[a+"_wealth"])-float(r[b+"_wealth"]), f"Bad {m}: {key(r)}")
        expected = r["always_wait_wealth"] if int(r["signal_wait"]) else r["fixed_wealth"]
        close(expected, r["flex_wealth"], "Signal selection")
    for sample in rows(OUT / "samples.csv"):
        if sample["cost"] != "base":
            continue
        batch = defaultdict(list)
        m = sample["contrast"]
        for r in base:
            if r["cohort"] == sample["cohort"]:
                batch[r["last_old_session"]].append(float(r[m]))
        close(fmean(map(fmean, batch.values())), sample["equal_batch_mean"], f"Bad pooled {m}")
    for r in rows(OUT / "timing_bounds.csv"):
        check(float(r["perfect_information_ceiling"])+.00001 >= float(r["empirical_best_policy_mean"]) >= 0,
              "Impossible timing bound")
    for t in rows(OUT / "funding.csv"):
        close(int(float(t["old_d_close"]) < float(t["old_basis"])), t["old_paper_loss"], "Loss group")
    # Check each historical decision with a separately assembled training sample.
    past = defaultdict(list)
    for r in base:
        if r["cohort"] == "other_batches":
            past[r["last_old_session"]].append((int(r["signal_wait"]),float(r["wait_minus_fixed"])))
    for r in rows(OUT / "information_by_date.csv"):
        train = [v for d,v in past.items() if d < r["date"]]
        check(len(train)==int(r["earlier_dates"]), "Forward training dates")
        means = [fmean(fmean(val if g==i else 0 for g,val in batch) for batch in train) for i in (0,1)]
        signs = [int(x > 0) for x in means]
        check(signs==[int(r["delay_no_decline"]),int(r["delay_decline"])], "Signal used future data")
        fixed = int(sum(means)>0)
        check(int(r["fixed_delay"])==fixed, "Fixed training benchmark")
        close(fmean((signs[g]-fixed)*val for g,val in past[r["date"]]),r["increment"],"Forward payoff")
    moments = [(fmean(s for s,v in batch), fmean(v for s,v in batch),
                fmean(v*s for s,v in batch)) for batch in past.values()]
    rate, gain, total = map(fmean,zip(*moments))
    random_quota = fmean(p*g for p,g,_ in moments)
    attribution = {r["component"]:r for r in rows(OUT/"timing_attribution.csv")}
    for name,expected in (("calendar",rate*gain),("between_dates",random_quota-rate*gain),
                          ("within_date",total-random_quota),("total",total),
                          ("information_association",total-rate*gain)):
        close(attribution[name]["estimate"],expected,name)
    dates = sorted(past)
    for r in rows(OUT/"common_test_window.csv"):
        actual = []
        for i in range(8,len(dates)):
            start = 0 if r["training_batches"]=="expanding" else i-int(r["training_batches"])
            train = [past[d] for d in dates[start:i]]
            weights = [fmean(fmean(v*(s==g) for s,v in batch) for batch in train) for g in (0,1)]
            group = past[dates[i]]
            fixed = int(sum(weights)>0)*fmean(v for s,v in group)
            policy = fmean(int(weights[s]>0)*v for s,v in group)
            actual.append((fixed, policy-fixed, policy))
        check((r["first"],r["last"],int(r["dates"]))==(dates[8],dates[-1],len(actual)), "Common dates")
        for k,v in zip(("calendar","information","total"),map(fmean,zip(*actual))):
            close(r[k],v,"Common-date "+k)
    funding = rows(OUT/"funding_bounds.csv")
    for group in ("all","loss"):
        tr = [r for r in funding if r["group"] == group]
        check(len(tr)==101,"Missing probability grid")
        for i,r in enumerate(tr):
            close(r["p"],i/100,"Probability grid")
            check(float(r["lower"])-1e-6<=float(r["independent"])<=float(r["upper"])+1e-6,"Funding bounds")
            close(float(r["lower"])+float(tr[100-i]["upper"]),float(tr[0]["lower"])+float(tr[-1]["lower"]),
                  "Complementary-tail identity")
    print(f"Verified {len(events)} listed deletions across {len({k[0] for k in ids})} dates, "
          f"{len(base)} base-case pairs, {len(ex)} exclusions, and paired-wealth identities.")


if __name__ == "__main__":
    main()
