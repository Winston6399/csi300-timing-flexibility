"""Same-stock pre-event diagnostic and an explicitly funded retail-account scenario."""
import csv
from collections import defaultdict
from statistics import fmean

from analyze import COSTS, cohort, dates_for_batch, load_bars, load_events, prepare_pair
from fetch import ROOT, symbol_for


def write(name, data, fields):
    with (ROOT / "results" / name).open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)


def price_data(code, day):
    return load_bars(ROOT / "input" / "cache" / f"{code}_{day}.json", symbol_for(code))


def funding(event, stock, fund, calendar, days, records):
    """Old ETF bought 20 sessions earlier. Sell at D close or D+1 open."""
    ix = calendar.index(days[1])
    basis_day, d, first, second = calendar[ix - 20], days[1], days[2], days[3]
    etf_rows = [fund[k] for k in calendar[ix-20:ix+2]]
    if any(r[4] <= 0 or any(isinstance(x, dict) for x in r[5]) for r in etf_rows):
        raise ValueError("old ETF has an action or zero volume")
    etf_basis, etf_now, etf_open = fund[basis_day][1], fund[d][1], fund[first][0]
    commission, minimum, slip = COSTS["base"]

    def debit(q, p):
        gross = q * p * (1 + slip)
        return gross + max(minimum, gross * commission)

    def proceeds(q, p):
        gross = q * p * (1 - slip)
        return gross - max(minimum, gross * commission)

    # Initial old position at the observed close is a specified investor state.
    # Cost basis is used solely to define its hypothetical paper gain or loss.
    etf_qty = int((10_000 - minimum) / (etf_basis * (1 + slip) * (1 + commission)) / 100) * 100
    if etf_qty <= 0:
        raise ValueError("ETF order too small")
    free = 10_000 - debit(etf_qty, etf_basis)
    cash_pre = free + proceeds(etf_qty, etf_now)
    cash_jit = free + proceeds(etf_qty, etf_open)
    # Use the same ex-ante stock quantity as in the main experiment.
    q = records["shares"]
    if not q:
        raise ValueError("zero target shares")
    using = [debit(q, stock[k][0]) for k in (first, second)]
    if free >= min(using):
        raise ValueError("funding not binding")
    if cash_pre < using[0] or cash_jit < max(using):
        raise ValueError("funding capacity fails")
    if records["fixed_status"] != "filled" or records["always_wait_status"] != "filled":
        raise ValueError("target not filled in both scenarios")
    # Both liquidation scenarios receive the same ETF dividend treatment.
    # Common final stock holdings cancel. Cash accrual is set to zero.
    wealth_d = free + etf_qty * etf_now
    fast = (cash_pre - using[0]) - (cash_jit - using[0])
    slow = (cash_pre - using[0]) - (cash_jit - using[1])
    return dict(old_basis_day=basis_day, old_basis=etf_basis, old_d_close=etf_now,
                old_next_open=etf_open, old_shares=etf_qty, old_paper_loss=int(etf_now < etf_basis),
                old_wealth_d=round(wealth_d, 6), target_shares=q,
                prefund_vs_immediate=round(10000*fast/wealth_d, 6),
                prefund_vs_one_day_delay=round(10000*slow/wealth_d, 6))


def main():
    output = ROOT / "results"
    with (output / "pairs.csv").open(encoding="utf-8-sig") as f:
        main_rows = {(p["last_old_session"], p["code"]): p for p in csv.DictReader(f) if p["cost"] == "base"}
    flag_file = ROOT / "input" / "corporate_actions.csv"
    import_actions = set()
    if flag_file.exists():
        with flag_file.open(encoding="utf-8-sig") as f:
            import_actions = {(r["code"], r["date"]) for r in csv.DictReader(f)}
    placebo, funded, skipped = [], [], []
    for event in load_events(ROOT):
        d, code = event["last_old_session"], event["code"]
        key = dict(last_old_session=d, code=code, cohort=cohort(d))
        if (d, code) not in main_rows:
            continue
        primary = main_rows[d, code]
        stock = price_data(code, d)
        calendar = sorted(price_data("000300", d))
        position = calendar.index(d)
        days = dates_for_batch(calendar, d)
        if position < 21:
            raise ValueError("Less than 21 sessions of index history")
        fake = calendar[position-20]
        fake_event = dict(event, last_old_session=fake, notice_date=fake)
        try:
            rec = next(p for p in prepare_pair(fake_event, stock, dates_for_batch(calendar, fake), import_actions)
                       if p["cost"] == "base")
            delta = float(primary["flex_minus_fixed"]) - rec["flex_minus_fixed"]
            placebo.append(dict(**key, placebo_anchor=fake, actual=float(primary["flex_minus_fixed"]),
                                placebo=rec["flex_minus_fixed"], actual_minus_placebo=round(delta, 6)))
        except (KeyError, ValueError) as ex:
            skipped.append(dict(**key, extension="placebo", reason=str(ex)))
        try:
            fund = price_data("510300", d)
            types = dict(primary, shares=int(primary["shares"]))
            funded.append(dict(**key, **funding(event, stock, fund, calendar, days, types)))
        except (FileNotFoundError, KeyError, ValueError) as ex:
            skipped.append(dict(**key, extension="funding", reason=str(ex)))

    keys = ["last_old_session", "code", "cohort"]
    write("placebo.csv", placebo, keys + ["placebo_anchor","actual","placebo","actual_minus_placebo"])
    write("funding.csv", funded, keys + ["old_basis_day","old_basis","old_d_close","old_next_open",
          "old_shares","old_paper_loss","old_wealth_d","target_shares","prefund_vs_immediate","prefund_vs_one_day_delay"])
    write("extension_exclusions.csv", skipped, keys + ["extension", "reason"])
    summaries = []
    for name, data, metrics in [
        ("placebo", placebo, ["actual","placebo","actual_minus_placebo"]),
        ("funding_all", funded, ["prefund_vs_immediate","prefund_vs_one_day_delay"]),
        ("funding_old_loss", [r for r in funded if r["old_paper_loss"]], ["prefund_vs_immediate","prefund_vs_one_day_delay"]),
    ]:
        for label in sorted({r["cohort"] for r in data}):
            group = [r for r in data if r["cohort"] == label]
            for metric in metrics:
                batches = defaultdict(list)
                for rec in group:
                    batches[rec["last_old_session"]].append(rec[metric])
                means = [fmean(values) for values in batches.values()]
                summaries.append(dict(extension=name, cohort=label, metric=metric, pairs=len(group),
                                      batches=len(means), equal_batch_mean=round(fmean(means), 6),
                                      positive_batches=sum(v > 0 for v in means)))
    write("extension_summary.csv", summaries, ["extension","cohort","metric","pairs","batches","equal_batch_mean","positive_batches"])
    bounds = []
    for label in sorted({row["cohort"] for row in main_rows.values()}):
        by_batch = defaultdict(list)
        for row in main_rows.values():
            if row["cohort"] == label:
                by_batch[row["last_old_session"]].append(row)
        def equal_batch(metric):
            return fmean(fmean(metric(row) for row in group) for group in by_batch.values())
        rule = equal_batch(lambda row: float(row["flex_minus_fixed"]))
        delay = equal_batch(lambda row: float(row["wait_minus_fixed"]))
        oracle = equal_batch(lambda row: max(0, float(row["wait_minus_fixed"])))
        bounds.append(dict(cohort=label, batches=len(by_batch), pairs=sum(map(len, by_batch.values())),
                           feasible_rule_gain=round(rule, 6), fixed_delay_gain=round(delay, 6),
                           empirical_best_policy_mean=round(max(0, rule, delay), 6),
                           perfect_information_ceiling=round(oracle, 6)))
    write("timing_bounds.csv", bounds, ["cohort","batches","pairs","feasible_rule_gain","fixed_delay_gain",
                                        "empirical_best_policy_mean","perfect_information_ceiling"])
    audit_path = ROOT / "results" / "market_check.csv"
    if audit_path.exists():
        with audit_path.open(encoding="utf-8-sig") as f:
            passed = {(r["last_old_session"], r["code"]) for r in csv.DictReader(f)
                      if r.get("primary_provider", "").lower() not in ("","sohu")
                      and r["status"] not in ("error","same_source")
                      and all(r[k].endswith(":ok") for k in ("d","d1","d2","d5"))}
        audited = defaultdict(list)
        for key, r in main_rows.items():
            if key in passed:
                audited[r["cohort"],key[0]].append(float(r["flex_minus_fixed"]))
        records = []
        for label in sorted({k[0] for k in audited}):
            batches = [v for (group,d),v in audited.items() if group==label]
            records.append(dict(cohort=label, pairs=sum(map(len,batches)), batches=len(batches),
                                equal_batch_mean=round(fmean(map(fmean,batches)),6)))
        write("dual_source_sensitivity.csv", records, ["cohort","pairs","batches","equal_batch_mean"])


if __name__ == "__main__":
    main()
