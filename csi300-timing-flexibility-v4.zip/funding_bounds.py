"""Sharp empirical bounds with an unknown dependence between delay and payoffs."""
import csv
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent / "results"


def tail(values, probability, highest):
    total = 0.0
    remaining = probability
    for spread, weight in sorted(values, reverse=highest):
        take = min(weight, remaining)
        total += take * spread
        remaining -= take
        if remaining <= 1e-12:
            break
    return total


def main():
    with (OUT/"funding.csv").open(encoding="utf-8-sig") as f:
        main = [r for r in csv.DictReader(f) if r["cohort"] == "other_batches"]
    results = []
    for group, data in (("all",main),("loss",[r for r in main if r["old_paper_loss"]=="1"])):
        counts = Counter(r["last_old_session"] for r in data)
        base, values = 0.0, []
        for r in data:
            weight = 1/(len(counts)*counts[r["last_old_session"]])
            fast = float(r["prefund_vs_immediate"])
            base += weight * fast
            values.append((float(r["prefund_vs_one_day_delay"])-fast,weight))
        slope = sum(v*w for v,w in values)
        for i in range(101):
            p = i/100
            lo = base + tail(values,p,False)
            hi = base + tail(values,p,True)
            ind = base+p*slope
            if not lo-1e-6 <= ind <= hi+1e-6:
                raise ValueError("independent assignment outside the envelope")
            results.append(dict(group=group,p=p,pairs=len(data),batches=len(counts),lower=lo,
                independent=ind,upper=hi,independent_crossing=(-base/slope if slope and 0<=-base/slope<=1 else "")))
    with (OUT/"funding_bounds.csv").open("w",encoding="utf-8",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)


if __name__=="__main__":
    main()
