"""Audit event-stock quotes against Sohu and flag changes to the reference price."""
import argparse
import csv
import hashlib
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from decimal import Decimal
from functools import partial
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from analyze import dates_for_batch, load_events
from fetch import ROOT, symbol_for

POINTS = {"d": 1, "d1": 2, "d2": 3, "d5": 6}
AUDIT = ["last_old_session", "code", "name", "status", "error", "url", "sha256",
         "primary_provider", "sohu_rows", "primary_rows", "missing_dates", "quote_mismatches",
         "reference_discontinuities", *POINTS]
ACTIONS = ["code", "date", "last_old_session", "prior_close", "reference_close",
           "reference_minus_prior", "primary_provider", "url"]


def cached_window(code, anchor):
    path = ROOT / "input" / "cache" / f"{code}_{anchor}.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = data["data"][symbol_for(code)]["day"]
    host = urlparse(data.get("source_url", "https://web.ifzq.gtimg.cn")).hostname
    return {r[0]: r for r in rows}, host


def decode_sohu(payload, code):
    records = json.loads(payload.decode("gb18030"))
    if not isinstance(records, list) or len(records) != 1:
        raise ValueError("Sohu returned no stock record")
    record = records[0]
    if record["status"] != 0 or record.get("code") != "cn_" + code:
        raise ValueError("unexpected Sohu status or symbol")
    rows = record["hq"]
    dates = [r[0] for r in rows]
    if not rows or len(dates) != len(set(dates)) or any(len(r) < 7 for r in rows):
        raise ValueError("empty, duplicate or incomplete Sohu history")
    return {r[0]: r for r in rows}


def fetch_sohu(url, code, anchor, offline=False):
    base_url = url.partition("&stat=")[0]
    # The optional aggregate statistics do not change the raw daily-price fields.
    variants = [url, base_url + "&stat=1&order=A&period=d", base_url,
                base_url + "&stat=0&order=D&period=d", base_url + "&period=d"]
    cache = ROOT / "input" / "sohu_cache" / f"{code}_{anchor}.bin"
    if cache.exists():
        queried, _, payload = cache.read_bytes().partition(b"\n")
        queried_url = queried.decode("ascii")
        if queried_url not in variants:
            raise ValueError("Unrecognized source URL in Sohu cache")
        return decode_sohu(payload, code), hashlib.sha256(payload).hexdigest(), queried_url
    if offline:
        raise FileNotFoundError(f"No cached Sohu response for {code} {anchor}")
    for attempt, queried_url in enumerate(variants):
        try:
            req = Request(queried_url, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://q.stock.sohu.com/"})
            with urlopen(req, timeout=12) as response:
                payload = response.read()
            rows = decode_sohu(payload, code)
            cache.parent.mkdir(exist_ok=True, parents=True)
            temp = cache.with_suffix(f".{os.getpid()}.part")
            temp.write_bytes(queried_url.encode("ascii") + b"\n" + payload)
            temp.replace(cache)
            return rows, hashlib.sha256(payload).hexdigest(), queried_url
        except (ValueError, KeyError, OSError):
            if attempt == len(variants) - 1:
                raise
            time.sleep(0.8 * (attempt + 1))


def quotes_equal(tx, sh):
    return Decimal(str(tx[1])) == Decimal(sh[1]) and Decimal(str(tx[2])) == Decimal(sh[2])


def check(row, offline=False):
    code, anchor = row["code"], row["last_old_session"]
    d = date.fromisoformat(anchor)
    start, end = d - timedelta(days=85), d + timedelta(days=16)
    url = (f"https://q.stock.sohu.com/hisHq?code=cn_{code}&start={start:%Y%m%d}"
           f"&end={end:%Y%m%d}&stat=0&order=A&period=d")
    out = dict(last_old_session=anchor, code=code, name=row["name"], url=url)
    actions = []
    try:
        sh, out["sha256"], out["url"] = fetch_sohu(url, code, anchor, offline)
        out["sohu_rows"] = len(sh)
        tx, out["primary_provider"] = cached_window(code, anchor)
        out["primary_rows"] = len(tx)
        calendar, _ = cached_window("000300", anchor)
        days = dates_for_batch(calendar, anchor)
        if not days:
            raise ValueError("index calendar missing event window")
        same_source = out["primary_provider"].lower().endswith("sohu.com")
        missing = sorted(sh.keys() ^ tx.keys())
        mismatches = [t for t in sorted(sh.keys() & tx.keys()) if not quotes_equal(tx[t], sh[t])]
        out["missing_dates"], out["quote_mismatches"] = "|".join(missing), "|".join(mismatches)
        for marker, i in POINTS.items():
            t = days[i]
            if t not in sh or t not in tx:
                out[marker] = f"{t}:missing"
            else:
                out[marker] = f"{t}:ok" if quotes_equal(tx[t], sh[t]) else f"{t}:mismatch"
        # On an ordinary trading day Sohu close minus signed change should equal
        # the preceding stock-session close. A break is a screening flag. Corporate
        # action type cannot be inferred from daily quotes alone.
        tx_days = sorted(tx)
        sh_days = sorted(sh)
        sh_previous = dict(zip(sh_days[1:], sh_days[:-1]))
        for prev, t in zip(tx_days, tx_days[1:]):
            if sh_previous.get(t) != prev or prev in mismatches or t in mismatches:
                continue
            ref = Decimal(sh[t][2]) - Decimal(sh[t][3])
            old = Decimal(sh[prev][2])
            if abs(ref - old) >= Decimal("0.01"):
                actions.append(dict(code=code, date=t, last_old_session=anchor,
                                    prior_close=old, reference_close=ref,
                                    reference_minus_prior=ref - old,
                                    primary_provider=out["primary_provider"], url=out["url"]))
        out["reference_discontinuities"] = len(actions)
        if same_source:
            out["status"] = "same_source"
        elif mismatches or missing or any(not out[m].endswith(":ok") for m in POINTS):
            out["status"] = "review"
        else:
            out["status"] = "matched"
    except (KeyError, ValueError, OSError, ArithmeticError) as e:
        out.update(status="error", error=f"{type(e).__name__}: {e}")
    return out, actions


def save(path, fields, rows):
    path.parent.mkdir(exist_ok=True, parents=True)
    temp = path.with_suffix(".writing")
    with temp.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fields)
        w.writeheader()
        w.writerows(rows)
    temp.replace(path)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--workers", type=int, default=3, choices=range(1, 7))
    ap.add_argument("--offline", action="store_true", help="Use only previously downloaded Sohu responses")
    args = ap.parse_args()
    events = load_events(ROOT)
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(partial(check, offline=args.offline), events))
    audits = [audit for audit, _ in results]
    flags = [action for _, actions in results for action in actions]
    save(ROOT / "results" / "market_check.csv", AUDIT, audits)
    save(ROOT / "input" / "corporate_actions.csv", ACTIONS, flags)
    errors = sum(a["status"] == "error" for a in audits)
    matched = sum(a["status"] == "matched" for a in audits)
    same_source = sum(a["status"] == "same_source" for a in audits)
    print(f"{len(audits)} stock windows: {matched} matched, {errors} unavailable, "
          f"{same_source} same source, {len(audits)-matched-errors-same_source} require review. "
          f"{len(flags)} reference-price flags.")
    return int(errors > 0)


if __name__ == "__main__":
    raise SystemExit(main())
