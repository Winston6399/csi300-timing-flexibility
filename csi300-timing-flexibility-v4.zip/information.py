"""Two-action value of information under equal weighting of rebalance dates."""
import csv
import random
from collections import defaultdict
from pathlib import Path
from statistics import fmean

OUT = Path(__file__).resolve().parent / "results"


def save(name, rows):
    with (OUT/name).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def evaluate(groups, burn, lookback=None):
    history, test = [], []
    for day, (a,b,perfect) in sorted(groups.items()):
        if len(history) >= burn:
            train = history if lookback is None else history[-lookback:]
            h0 = fmean(t[0] for t in train)
            h1 = fmean(t[1] for t in train)
            # Positive sums are equivalent to positive conditional means.
            fixed = int(h0+h1 > 0)
            quiet, down = int(h0 > 0), int(h1 > 0)
            adapt = quiet*a + down*b
            test.append(dict(burn_in=burn, date=day, earlier_dates=len(history),
                delay_no_decline=quiet, delay_decline=down, fixed_delay=fixed,
                policy_gain=adapt, fixed_gain=fixed*(a+b),
                increment=adapt-fixed*(a+b), oracle=perfect, always_late=a+b))
        history.append((a,b))
    return test


def main():
    groups = defaultdict(list)
    with (OUT/"pairs.csv").open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            if r["cost"] == "base" and r["cohort"] == "other_batches":
                groups[r["last_old_session"]].append((int(r["signal_wait"]), float(r["wait_minus_fixed"])))
    stats = {d: (fmean(v*(s==0) for s,v in a), fmean(v*(s==1) for s,v in a),
                 fmean(max(0,v) for s,v in a)) for d,a in groups.items()}
    moments = [(fmean(s for s,v in a), fmean(v for s,v in a), fmean(s*v for s,v in a))
               for d,a in sorted(groups.items())]
    def decompose(items):
        p, delta, total = map(fmean, zip(*items))
        marginal = p*delta
        quota = fmean(rate*gain for rate,gain,_ in items)
        return dict(calendar=marginal, between_dates=quota-marginal,
                    within_date=total-quota, information_association=total-marginal,
                    total=total, delay_rate=p)
    values = decompose(moments)
    rng = random.Random(261126)
    draws = [decompose(rng.choices(moments,k=len(moments))) for _ in range(5000)]
    components = []
    for name,estimate in values.items():
        distribution = sorted(r[name] for r in draws)
        components.append(dict(component=name, estimate=estimate,
                               low=distribution[124], high=distribution[4874]))
    save("timing_attribution.csv", components)
    windows = []
    for lookback in (4,6,8,None):
        tested = evaluate(stats, 8, lookback)
        windows.append(dict(training_batches=lookback or "expanding", first=tested[0]["date"],
            last=tested[-1]["date"], dates=len(tested), calendar=fmean(t["fixed_gain"] for t in tested),
            information=fmean(t["increment"] for t in tested), total=fmean(t["policy_gain"] for t in tested)))
    save("common_test_window.csv",windows)
    results, summary = [], []
    for burn in (4,6,8):
        test = evaluate(stats, burn)
        results.extend(test)
        a,b,oracle = [fmean(t[i] for t in stats.values()) for i in range(3)]
        plug_in = max(0,a)+max(0,b)-max(0,a+b)
        inc = fmean(t["increment"] for t in test)
        summary.append(dict(burn_in=burn, test_dates=len(test), test_increment=inc,
                calendar=fmean(t["fixed_gain"] for t in test), total=fmean(t["policy_gain"] for t in test),
                gain_vs_best_test_fixed=fmean(t["policy_gain"] for t in test)-max(0,fmean(t["always_late"] for t in test)),
                positive_dates=sum(t["increment"]>0.000001 for t in test),
                negative_dates=sum(t["increment"]<-.000001 for t in test),
                policies_identical_dates=sum(t["delay_no_decline"]==t["delay_decline"]==t["fixed_delay"] for t in test),
                pooled_signal_value=plug_in, perfect_above_best_fixed=oracle-max(0,a+b)))
    save("information_by_date.csv", results)
    save("information_summary.csv", summary)


if __name__ == "__main__":
    main()
