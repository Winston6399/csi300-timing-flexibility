"""Fetch bounded public daily-bar windows for the event manifest (Python 3.10+)."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / "input" / "cache"
BASE = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
EAST = "https://push2his.eastmoney.com/api/qt/stock/kline/get"
SOHU = "https://q.stock.sohu.com/hisHq"


def symbol_for(code):
    if code in ("000300", "510300"):
        return "sh" + code
    return ("sh" if code.startswith(("6", "9")) else "sz") + code


def get_jobs(manifests):
    jobs = set()
    for manifest in manifests:
        with manifest.open(encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                code, day = row["code"], row["last_old_session"]
                if len(code) != 6 or not code.isascii() or not code.isdigit():
                    raise ValueError(f"Invalid stock code in {manifest}: {code}")
                date.fromisoformat(day)
                jobs.update((item, day) for item in (code, "000300", "510300"))
    return sorted(jobs)


def read_remote(url):
    req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(req, timeout=14) as response:
        payload = response.read()
    try:
        return json.loads(payload)
    except UnicodeDecodeError:
        return json.loads(payload.decode("gb18030"))


def east_bars(url, code):
    data = read_remote(url)["data"]
    if not data or data["code"] != code:
        raise ValueError("missing Eastmoney stock ID")
    rows, previous = [], None
    for record in data["klines"]:
        s = record.split(",")
        bar = s[:6]
        # Open, close, high, low and volume are already in canonical order.
        # Eastmoney's signed price change is rounded; apply an instrument tick.
        tick = 10**(-int(data["decimal"]))
        ref = float(s[2]) - float(s[9])
        if previous is not None and abs(ref-previous) > max(.0051, 0.8*tick):
            bar.append({"cqr": s[0], "reference_break": round(ref-previous, 5)})
        previous = float(s[2])
        rows.append(bar)
    return rows


def sohu_bars(url, code, day):
    path = ROOT/"input"/"sohu_cache"/f"{code}_{day}.bin"
    if path.exists():
        source, raw = path.read_bytes().split(b"\n",1)
        quote = json.loads(raw.decode("gb18030"))[0]
        url = source.decode("ascii")
    else:
        quote = read_remote(url)[0]
    if quote.get("status") != 0 or quote.get("code","").split("_")[-1] != code:
        raise ValueError("missing Sohu series")
    rows, previous = [], None
    for s in sorted(quote["hq"]):
        bar = [s[i] for i in (0,1,2,6,5,7)]
        ref = float(s[2]) - float(s[3])
        if previous is not None and abs(ref-previous) > .0051:
            bar.append({"cqr": s[0], "reference_break": round(ref-previous, 5)})
        previous = float(s[2])
        rows.append(bar)
    return rows, url


def fetch(job, preferred="tencent", pinned_url=""):
    code, day = job
    symbol = symbol_for(code)
    anchor = date.fromisoformat(day)
    start, end = anchor - timedelta(days=85), anchor + timedelta(days=16)
    tx_url = f"{BASE}?param={symbol},day,{start},{end},128,"
    market = "1" if symbol.startswith("sh") else "0"
    em_url = (f"{EAST}?secid={market}.{code}&klt=101&fqt=0&beg={start:%Y%m%d}&end={end:%Y%m%d}"
              "&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61")
    sohu_code = ("zs_" if code == "000300" else "cn_") + code
    sohu_url = f"{SOHU}?code={sohu_code}&start={start:%Y%m%d}&end={end:%Y%m%d}&stat=1&order=A&period=d"
    if pinned_url.startswith(SOHU+"?"):
        sohu_url = pinned_url
    providers = [preferred] + [p for p in ("eastmoney","sohu","tencent") if p != preferred]
    url = tx_url
    path = CACHE / f"{code}_{day}.json"
    for attempt in range(3):
        try:
            if path.exists():
                payload = path.read_bytes()
                obj = json.loads(payload)
                rows = obj["data"][symbol]["day"]
                url = obj.get("source_url", tx_url)
            else:
                provider = providers[attempt]
                url = {"tencent":tx_url, "eastmoney":em_url, "sohu":sohu_url}[provider]
                if provider == "eastmoney":
                    rows = east_bars(url, code)
                elif provider == "sohu":
                    rows, url = sohu_bars(url, code, day)
                else:
                    data = read_remote(url)
                    if data.get("code") not in (0, "0"):
                        raise ValueError(str(data.get("msg", "service error")))
                    rows = data["data"].get(symbol, {}).get("day", [])
                # Store stable history only. The same endpoint includes a live quote.
                obj = {"data": {symbol: {"day": rows}}}
                if provider != "tencent":
                    obj["source_url"] = url
                payload = json.dumps(obj,
                                     ensure_ascii=False, separators=(",", ":")).encode()
            dates = [bar[0] for bar in rows]
            if not dates or not all(start.isoformat() <= d <= end.isoformat() for d in dates):
                raise ValueError("empty or out-of-range history")
            if dates != sorted(set(dates)):
                raise ValueError("unordered or duplicate dates")
            if not path.exists():
                tmp = path.with_suffix(".part")
                tmp.write_bytes(payload)
                tmp.replace(path)
            return (code, day, len(rows), hashlib.sha256(payload).hexdigest(), url, "")
        except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError) as e:
            error = f"{type(e).__name__}: {e}"
            if not path.exists():
                time.sleep(0.5 * (attempt + 1))
    return (code, day, 0, "", url, error)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("manifest", nargs="*", type=Path)
    ap.add_argument("--workers", type=int, default=3, choices=range(1, 7))
    ap.add_argument("--prefer", choices=("tencent", "eastmoney","sohu"), default="tencent")
    args = ap.parse_args()
    manifests = args.manifest or [p for p in (ROOT / "events.csv", ROOT / "events_recent.csv") if p.exists()]
    if not manifests:
        ap.error("No event manifest")
    jobs = get_jobs(manifests)
    CACHE.mkdir(parents=True, exist_ok=True)
    pinned = {}
    release_manifest = ROOT / "data_manifest.csv"
    if release_manifest.exists():
        with release_manifest.open(encoding="utf-8-sig", newline="") as f:
            pinned = {(r["code"], r["last_old_session"]): r for r in csv.DictReader(f)}
    def preferred(job):
        item = pinned.get(job)
        if item and item["rows"] != "0":
            if "eastmoney.com/" in item["url"]:
                return "eastmoney"
            return "sohu" if "sohu.com/" in item["url"] else "tencent"
        return args.prefer
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(lambda job: fetch(job, preferred(job),
                        pinned.get(job, {}).get("url","")), jobs))
    audit = ROOT / "input" / "fetch_audit.csv"
    with audit.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(("code", "last_old_session", "rows", "sha256", "url", "error"))
        writer.writerows(results)
    failures = [r for r in results if r[-1]]
    if pinned:
        with (ROOT/"input"/"fetch_drift.csv").open("w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(("code","last_old_session","released_sha256","current_sha256"))
            for r in results:
                expected = pinned.get((r[0],r[1]), {}).get("sha256")
                if expected is not None and expected != r[3]:
                    writer.writerow((r[0], r[1], expected, r[3]))
    print(f"{len(results) - len(failures)} of {len(results)} windows available. See {audit}.")
    for row in failures:
        print(row[0], row[1], row[-1], file=sys.stderr)
    return int(bool(failures))


if __name__ == "__main__":
    sys.exit(main())
