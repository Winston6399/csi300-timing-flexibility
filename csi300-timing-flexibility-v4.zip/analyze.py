"""Compare pre-specified execution dates on cached, unadjusted Tencent daily bars."""
import argparse
import csv
import json
import random
from collections import defaultdict
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from statistics import fmean, median


ROOT = Path(__file__).resolve().parent
CASH = 10_000.0
RESERVE = 1.25
# commission fraction, minimum commission in CNY, assumed adverse buy slippage
COSTS = {
    "zero": (0, 0, 0),
    "base": (.0003, 5, .0005),
    "stress": (.0005, 5, .0020),
}
ARMS = ("fixed", "flex", "always_wait")
DIFFS = {"flex_minus_fixed": ("flex", "fixed"),
         "wait_minus_fixed": ("always_wait", "fixed"),
         "flex_minus_wait": ("flex", "always_wait")}


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def save_csv(path, rows, fields):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def source_paths(base, name):
    return [path for path in (base / "input" / name, base / name) if path.exists()]


def load_events(base):
    events = {}
    for name in ("events.csv", "events_recent.csv"):
        for path in source_paths(base, name):
            for row in read_csv(path):
                row["code"] = row["code"].strip().zfill(6)
                ident = (row["last_old_session"], row["code"])
                if ident in events and row["notice_date"] != events[ident]["notice_date"]:
                    raise ValueError(f"Conflicting notice dates for {ident}")
                events[ident] = row
    if not events:
        raise ValueError("No event rows found in events.csv or events_recent.csv")
    return [events[k] for k in sorted(events)]


def load_bars(raw, sym):
    """Each daily row has date, open, close, high, low, volume, optional action metadata."""
    payload = json.loads(raw.read_text(encoding="utf-8-sig"))
    rows = payload["data"][sym]["day"]
    bars = {}
    for row in rows:
        if len(row) < 6:
            raise ValueError("short daily bar")
        day = date.fromisoformat(row[0]).isoformat()
        if day in bars:
            raise ValueError("duplicate daily bar")
        bars[day] = tuple(float(x) for x in row[1:6]) + (row[6:],)
    return bars


def cohort(d):
    if d.startswith("2025-06"):
        return "explored_2025_06"
    if d.startswith("2025-12"):
        return "previously_seen_2025_12"
    return "other_batches"


def dates_for_batch(calendar, event_day):
    dates = sorted(calendar)
    if event_day not in dates:
        return None
    i = dates.index(event_day)
    if i < 1 or i + 5 >= len(dates):
        return None
    return dates[i-1:i+6]


def limit_rate(code, name, d):
    if code.startswith(("688", "689")) or (code.startswith(("300", "301")) and d >= "2020-08-24"):
        return .20
    return .05 if "ST" in name.upper() else .10


def limit_price(prev_close, rate):
    value = Decimal(str(prev_close)) * (Decimal(1) + Decimal(str(rate)))
    return float(value.quantize(Decimal(".01"), rounding=ROUND_HALF_UP))


def order_size(code, signal_close):
    raw = int(CASH / (RESERVE * signal_close))
    if code.startswith(("688", "689")):
        return raw if raw >= 200 else 0
    return raw // 100 * 100


def has_action(bar):
    return any(isinstance(x, dict) and (x.get("fh") or x.get("cq") or x.get("cqr") or x.get("fh_sh"))
               for x in bar[5])


def execution(open_price, prev_close, rate, shares, mark, costs):
    com, minimum, slip = costs
    if not shares:
        return CASH, "insufficient_for_minimum_order"
    if open_price >= limit_price(prev_close, rate) - .00001:
        return CASH, "opened_at_or_above_upper_limit"
    paid = shares * open_price * (1 + slip)
    debit = paid + max(paid * com, minimum)
    if debit > CASH:
        return CASH, "exceeds_budget"
    return CASH - debit + shares * mark, "filled"


def prepare_pair(event, bars, days, external, predicate=None):
    if days is None:
        raise ValueError("batch_calendar_window_incomplete")
    prev, d, one, two, *_, end = days
    if event["notice_date"] > d or not event["notice_date"]:
        raise ValueError("late_or_missing_notice_date")
    if any(day not in bars for day in days):
        raise ValueError("missing_daily_bar_or_suspension")
    if any(any(not (x > 0 and x < float("inf")) for x in bars[s][:5]) for s in days):
        raise ValueError("invalid_price_or_zero_volume")
    for s in days:
        o, c, h, low = bars[s][:4]
        if min(o, c) < low or max(o, c) > h:
            raise ValueError("inconsistent_daily_price_range")
    if any(has_action(bars[s]) for s in days[1:]):
        raise ValueError("corporate_action_bar_metadata")
    if any((event["code"], s) in external for s in days[1:]):
        raise ValueError("corporate_action_external_flag")
    if predicate:
        predicate(days)
    if not event["code"].startswith(("00", "30", "60", "68")):
        raise ValueError("unsupported_listing_board")
    q = order_size(event["code"], bars[d][1])
    down = bars[d][1] < bars[prev][1]
    out = {k: event[k] for k in ("code", "name", "notice_date", "last_old_session")}
    out.update(cohort=cohort(d), first_session=one, second_session=two, mark_date=end,
               close_before_d=bars[prev][1], close_d=bars[d][1],
               open_one=bars[one][0], open_two=bars[two][0], mark=bars[end][1],
               shares=q, signal_wait=int(down))
    rows = []
    for label, costs in COSTS.items():
        rec = dict(out, cost=label)
        for arm, day, prior in (("fixed", one, d), ("flex", two if down else one, one if down else d),
                                 ("always_wait", two, one)):
            rate = limit_rate(event["code"], event["name"], day)
            wealth, status = execution(bars[day][0], bars[prior][1], rate, q, bars[end][1], costs)
            rec[arm + "_wealth"] = round(wealth, 6)
            rec[arm + "_status"] = status
        for field, (first, second) in DIFFS.items():
            rec[field] = round(rec[first+"_wealth"] - rec[second+"_wealth"], 6)
        rows.append(rec)
    return rows


def bootstrap_batches(values):
    if len(values) < 5:
        return "", ""
    rng = random.Random(21439)
    draws = sorted(fmean(rng.choices(values, k=len(values))) for _ in range(5000))
    return round(draws[124], 4), round(draws[4874], 4)


def summarise(rows):
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["cohort"], row["cost"], row["last_old_session"])].append(row)
    batches = []
    for (group, cost, d), pairs in sorted(grouped.items()):
        b = dict(cohort=group, cost=cost, last_old_session=d, n=len(pairs),
                 signal_wait=sum(row["signal_wait"] for row in pairs))
        for field in DIFFS:
            b[field] = round(fmean(p[field] for p in pairs), 6)
        for arm in ARMS:
            b[arm+"_filled"] = sum(p[arm+"_status"] == "filled" for p in pairs)
        batches.append(b)
    samples = []
    for group, cost in sorted({key[:2] for key in grouped}):
        bs = [b for b in batches if (b["cohort"], b["cost"]) == (group, cost)]
        ps = [p for p in rows if (p["cohort"], p["cost"]) == (group, cost)]
        for field in DIFFS:
            values = [b[field] for b in bs]
            lo, hi = bootstrap_batches(values)
            samples.append(dict(cohort=group, cost=cost, contrast=field,
                                pairs=len(ps), batches=len(bs), wait_signals=sum(p["signal_wait"] for p in ps),
                                equal_pair_mean=round(fmean(p[field] for p in ps), 4),
                                equal_batch_mean=round(fmean(values), 4),
                                batch_median=round(median(values), 4),
                                positive_batches=sum(v > 0 for v in values),
                                min_batch=round(min(values), 4), max_batch=round(max(values), 4),
                                batch_bootstrap_low=lo, batch_bootstrap_high=hi))
    return batches, samples


def market_control(rows, cache, output, actions):
    """Beta-one, matched-notional diagnostic using a same-day CSI 300 ETF."""
    checked = []
    funds = {}
    metrics = ["market_flex","market_wait","adjusted_flex_minus_fixed",
               "adjusted_wait_minus_fixed","adjusted_flex_minus_wait"]
    for p in rows:
        if p["cost"] != "base":
            continue
        d, a, b = p["last_old_session"], p["first_session"], p["second_session"]
        rec = {k:p[k] for k in ("last_old_session","code","name","cohort","signal_wait","shares")}
        try:
            if d not in funds:
                funds[d] = load_bars(cache / f"510300_{d}.json", "sh510300")
            prices = funds[d]
            if any(has_action(prices[x]) or ("510300", x) in actions for x in (d, a, b)):
                raise ValueError("etf_action")
            if any(min(prices[x][:5]) <= 0 for x in (d, a, b)):
                raise ValueError("etf_invalid_bar")
            first_fill = p["fixed_status"] == "filled"
            late_fill = p["always_wait_status"] == "filled"
            if first_fill != late_fill:
                raise ValueError("unmatched_fills")
            exposure = p["shares"] * p["close_d"] if first_fill else 0
            units = exposure / prices[d][1]
            market_wait = units * (prices[a][0] - prices[b][0])
            market_flex = p["signal_wait"] * market_wait
            adj_flex = p["flex_minus_fixed"] - market_flex
            adj_wait = p["wait_minus_fixed"] - market_wait
            rec.update({k:round(val, 6) for k,val in zip(metrics, (market_flex, market_wait,
                                                                  adj_flex, adj_wait, adj_flex-adj_wait))})
            rec.update(status="ok", exposure_cny=round(exposure, 6), etf_close_d=prices[d][1],
                       etf_open_one=prices[a][0], etf_open_two=prices[b][0])
        except (ValueError, TypeError, OSError, KeyError, IndexError) as ex:
            rec["status"] = str(ex)
        checked.append(rec)
    save_csv(output / "market_control.csv", checked, ["last_old_session","code","name","cohort",
             "signal_wait","shares","status","exposure_cny","etf_close_d","etf_open_one","etf_open_two",*metrics])
    summary = []
    for group in sorted({r["cohort"] for r in checked}):
        good = [r for r in checked if r["cohort"] == group and r["status"] == "ok"]
        for m in metrics:
            by_day = defaultdict(list)
            for r in good:
                by_day[r["last_old_session"]].append(r[m])
            means = [fmean(v) for v in by_day.values()]
            if means:
                lo, hi = bootstrap_batches(means)
                summary.append(dict(cohort=group, metric=m, pairs=len(good), batches=len(means),
                                    equal_batch_mean=round(fmean(means), 6),
                                    positive_batches=sum(v>0 for v in means), batch_bootstrap_low=lo,
                                    batch_bootstrap_high=hi))
    save_csv(output / "market_control_summary.csv", summary, ["cohort","metric","pairs","batches",
             "equal_batch_mean","positive_batches","batch_bootstrap_low","batch_bootstrap_high"])


def run(base):
    events = load_events(base)
    cache = base / "input" / "cache"
    output = base / "results"
    output.mkdir(exist_ok=True)
    action_paths = source_paths(base, "corporate_actions.csv")
    external = {(row["code"].strip().zfill(6), row["date"]) for p in action_paths for row in read_csv(p)}
    data, calendars, errors = {}, {}, {}
    for d in {e["last_old_session"] for e in events}:
        try:
            calendars[d] = load_bars(cache / f"000300_{d}.json", "sh000300")
        except (OSError, IndexError, TypeError, ValueError, KeyError):
            calendars[d] = {}
    for e in events:
        code, d = e["code"], e["last_old_session"]
        sym = ("sh" if code.startswith(("6", "9")) else "sz") + code
        try:
            bars = load_bars(cache / f"{code}_{d}.json", sym)
            data[d, code] = bars
        except (OSError, IndexError, TypeError, ValueError, KeyError) as ex:
            errors[d, code] = "cache_" + type(ex).__name__
    rows, excluded = [], []
    for e in events:
        code, d = e["code"], e["last_old_session"]
        try:
            if (d, code) in errors:
                raise ValueError(errors[d, code])
            rows.extend(prepare_pair(e, data[d, code], dates_for_batch(calendars[d], d), external))
        except ValueError as ex:
            excluded.append(dict(last_old_session=d, code=code, name=e["name"], cohort=cohort(d), reason=str(ex)))
    batches, samples = summarise(rows)
    pair_fields = ["code","name","notice_date","last_old_session","cohort","first_session","second_session",
                   "mark_date","close_before_d","close_d","open_one","open_two","mark","shares","signal_wait","cost"]
    for arm in ARMS:
        pair_fields.extend((arm+"_wealth", arm+"_status"))
    pair_fields.extend(DIFFS)
    save_csv(output / "pairs.csv", rows, pair_fields)
    save_csv(output / "exclusions.csv", excluded, ["last_old_session","code","name","cohort","reason"])
    save_csv(output / "batches.csv", batches, ["cohort","cost","last_old_session","n","signal_wait",
                                                *DIFFS, *(a+"_filled" for a in ARMS)])
    save_csv(output / "samples.csv", samples, ["cohort","cost","contrast","pairs","batches","wait_signals",
             "equal_pair_mean","equal_batch_mean","batch_median","positive_batches","min_batch","max_batch",
             "batch_bootstrap_low","batch_bootstrap_high"])
    market_control(rows, cache, output, external)
    reasons = defaultdict(int)
    for e in excluded:
        reasons[e["reason"]] += 1
    meta = dict(total_events=len(events), included=len(rows)//len(COSTS), excluded=len(excluded),
                exclusion_reasons=dict(reasons),
                independent_action_file_present=bool(action_paths),
                independently_flagged_dates=len(external), base_summaries=[
                    s for s in samples if s["cost"] == "base"])
    (output / "summary.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    (output / "methods.md").write_text(METHODS, encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False, indent=2))


METHODS = """# Paired timing experiment

D is the last trading session under the old index composition. Days are real
sessions from the CSI 300 cash index bars listed in data_manifest.csv. Each deleted stock is a separate
counterfactual account starting with CNY 10,000. The individual accounts do not
compose a jointly tradable portfolio.

* All arms have identical initial cash, number of shares and terminal valuation
  date. Quantity is set after the D close, assuming a 25% purchase-price buffer.
  Ordinary orders are rounded down to 100-share lots. STAR orders require at
  least 200 shares and then permit whole-share increments.
* Fixed buys at the D+1 open. Flexible waits until D+2 if D close is strictly
  below the D-1 close, and otherwise buys at the D+1 open. Always-wait buys at
  the D+2 open regardless of the signal. No information after D selects the
  planned entry. Both subsequent opening prices are observed only for execution.
* Mark all arms at D+5 close on unadjusted daily bars without liquidation.
  Unspent cash earns zero; dividends and price adjustments are addressed by
  excluding flagged corporate-action windows. A common terminal sale fee would
  cancel for equal quantities when both arms fill, but would affect unmatched
  fills. The experiment is a comparison of net marked wealth at this horizon.
* Zero costs assumes all purchases at the open and no commission. Base uses
  buy commission 3 bp with a CNY 5 minimum and 5 bp adverse slippage. Stress
  uses 5 bp with the same minimum and 20 bp slippage. These are hypothetical
  costs; no assumption about the user's broker or access to the opening price.
* A budget breach, insufficient size or a buy order opening at the assumed upper
  price limit leaves the relevant arm in cash. A 0.01 CNY tick rounds the limit
  to nearest cent, half up. Board/date and announcement name determine the
  rate (ST name for main board); exact historical price limits and queue fills
  are unavailable here. This proxy is conservative for stocks that open at
  the limit and subsequently trade below it.
* If any daily bar or positive price/volume is absent on D-1 through D+5,
  the event is excluded; a missing bar alone does not identify a suspension.
  Tencent corporate-action markers (and optional independent action dates) on
  D through D+5 exclude the event. Missing markers do not prove the absence
  of a distribution. See exclusions.csv for the individual cases. Events with
  too little capital to trade any shares remain in the account-level comparison.
* Results in CNY per CNY 10,000 are numerically equal to basis points of initial
  wealth. The one-row-per-pair file reports all three costs. Each batch first
  averages pairs. The principal summary equally weights reconstitution batches;
  equal-pair summaries are also shown. Percentile intervals resample whole
  batches with replacement, 5,000 draws, seed 21439. With fewer than five
  batches no interval is printed. Even with more batches the bootstrap is
  descriptive and limited by market dependence. June 2025 and December 2025
  are separate pre-inspected cohorts excluded from other_batches. Historical
  data not used to set this rule are not a prospective test.
* market_control.csv, base-cost events only: scale the concurrent CSI 300 ETF
  (510300) D+1-to-D+2 open difference by the target's matched D-close notional
  divided by the ETF D close, allowing fractional ETF units for the diagnostic.
  Subtract this market component once for always-wait and on wait signals for
  flexible. Stocks unfilled on both dates have zero exposure; unmatched fills are
  excluded from this diagnostic. The ETF component uses raw prices without
  transaction costs. A beta of one is assumed. This comparison cannot isolate
  index flows from industry shocks, stock selection or individual stock betas.
"""


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=ROOT, help="directory containing input/ and results/")
    run(parser.parse_args().base)
