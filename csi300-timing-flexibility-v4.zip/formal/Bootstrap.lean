import Timing

open Timing

/-- Summarize a resample using exact integer numerators. Each date has
mass common, so all bootstrap replicates have the same denominator. -/
def association (stats : Array Batch) (line : String) : Except String Int := do
  let tokens := line.splitOn " "
  if tokens.length != stats.size then throw "Incorrect number of dates in a draw"
  let mut w := 0
  let mut g := 0
  let mut a := 0
  for token in tokens do
    let some i := token.toNat? | throw "Invalid date index"
    let some b := stats[i]? | throw "Date index out of range"
    w := w + b.waits
    g := g + b.late
    a := a + b.policy
  return mass*a - w*g

def main (args : List String) : IO Unit := do
  let [path] := args | throw (IO.userError "Expected one draw-file argument")
  let lines := (← IO.FS.lines path)
  if lines.size != 5000 then throw (IO.userError "Expected 5000 resamples")
  let stats := batches.toArray
  let mut values := #[]
  for line in lines do
    match association stats line with
    | .error e => throw (IO.userError e)
    | .ok x => values := values.push x
  let ranked := values.qsort (· < ·)
  if !(rounds ranked[124]! denom (-831) && rounds ranked[4874]! denom 1566) then
    throw (IO.userError "Sorted endpoints disagree with the paper")
  IO.println "Exact integer bootstrap replay: 5000 draws, ranks 125/4875, [-8.31, 15.66] yuan."
