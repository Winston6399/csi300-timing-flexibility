"""Run the pinned Lean kernel and replay the published batch bootstrap."""
import argparse
import os
from pathlib import Path
import random
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", default="lean", help="Lean 4.24.0 executable")
    lean = parser.parse_args().lean
    version = subprocess.check_output([lean, "--version"], cwd=HERE, text=True).strip()
    if "version 4.24.0," not in version:
        raise SystemExit(f"Expected Lean 4.24.0, found {version}")
    print(version, flush=True)
    subprocess.run([sys.executable, "generate.py", "--check"], cwd=HERE, check=True)
    with tempfile.TemporaryDirectory() as tmp:
        dest = Path(tmp)
        env = dict(os.environ, LEAN_PATH=str(dest))
        for module in ("Ledger", "Timing"):
            result = subprocess.run([lean, "--tstack=131072", "-o",
                                     str(dest / f"{module}.olean"), f"{module}.lean"],
                                    env=env, cwd=HERE, text=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT)
            print(result.stdout, end="", flush=True)
            result.check_returncode()
            if "sorryAx" in result.stdout or "warning:" in result.stdout:
                raise SystemExit("Unexpected proof warning or placeholder")
        draws = dest / "draws.txt"
        rng = random.Random(261126)
        with draws.open("w", encoding="ascii", newline="\n") as stream:
            for _ in range(5000):
                stream.write(" ".join(map(str, rng.choices(range(25), k=25))) + "\n")
        subprocess.run([lean, "--run", "Bootstrap.lean", str(draws)],
                       env=env, cwd=HERE, check=True)


if __name__ == "__main__":
    main()
