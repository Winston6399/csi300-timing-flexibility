import Ledger
import Std.Tactic

namespace Timing

/-- All amounts in this identity may be expressed over one common denominator.
mix is the independent date mix, quota the within-batch randomized policy. -/
theorem attribution (actual quota mix : Int) :
    actual = mix + (quota - mix) + (actual - quota) := by omega

theorem weighted_sum (k : Int) (xs : List Int) :
    (xs.map (fun x => k*x)).sum = k * xs.sum := by
  induction xs with
  | nil => simp
  | cons x xs ih => simp [ih, Int.mul_add]

/-- Under independent drawing, every signal is paired with every payoff.
Repeated elements encode unequal integer observation weights as well. -/
theorem independent_pairs (signals gains : List Int) :
    (signals.map (fun s => (gains.map (fun g => s*g)).sum)).sum =
      signals.sum * gains.sum := by
  induction signals with
  | nil => simp
  | cons s ss ih => simp [weighted_sum, Int.add_mul] at ih ⊢; exact ih

/-- Conditional optimization can choose the better action separately in each
signal state; fixed optimization chooses one action for both states. The
two inputs are *unconditional* state contributions on a common scale. -/
def positive (x : Int) : Int := if 0 < x then x else 0

theorem information_nonnegative (x y : Int) :
    positive (x + y) ≤ positive x + positive y := by
  unfold positive
  split <;> split <;> split <;> omega

theorem information_zero_iff (x y : Int) :
    positive x + positive y = positive (x + y) ↔
      (0 ≤ x ∧ 0 ≤ y) ∨ (x ≤ 0 ∧ y ≤ 0) := by
  unfold positive
  split <;> split <;> split <;> omega

def gain (r : Row) : Int := r.2.2.1 - r.2.1
def choose (s : Bool) (x : Int) : Int := if s then x else 0
def valid (r : Row) : Bool :=
  r.2.2.2 == (if r.1 then r.2.2.1 else r.2.1)

structure Batch where
  waits : Int
  late : Int
  policy : Int
  quota : Int
  oracle : Int
  deriving Inhabited

/-- common is divisible by each batch size. Each batch has total weight
common; quota uses two independent within-batch draws and has weight common². -/
def summarize (rows : List Row) : Batch := Id.run do
  let w := common / (rows.length : Int)
  let k := (rows.map fun r => choose r.1 1).sum
  let g := (rows.map gain).sum
  return ⟨w*k, w*g, w*(rows.map fun r => choose r.1 (gain r)).sum,
          w*w*k*g, w*(rows.map fun r => positive (gain r)).sum⟩

def batches := ledger.map summarize
def count : Int := batches.length
def mass := count * common
def totalGain := (batches.map Batch.late).sum
def policyGain := (batches.map Batch.policy).sum
def mix := (batches.map Batch.waits).sum * totalGain
def quotaGain := count * (batches.map Batch.quota).sum
def actual := mass * policyGain
def denom := mass * mass * scale

/-- Strict half-cent windows avoid any tie convention. X / D is in yuan. -/
def rounds (x d cents : Int) : Bool :=
  decide (0 < d ∧ (2*cents-1)*d < 200*x ∧ 200*x < (2*cents+1)*d)

set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem ledger_checks : ledger.length = 25 ∧ (ledger.map List.length).sum = 465 ∧
    ledger.all (fun b => b.length > 0 && common % (b.length : Int) == 0) = true ∧
    ledger.all (fun b => b.all valid) = true := by decide

theorem main_attribution :
    rounds actual denom 1860 = true ∧ rounds mix denom 1479 = true ∧
    rounds (quotaGain - mix) denom 585 = true ∧
    rounds (actual - quotaGain) denom (-204) = true ∧
    rounds (actual - mix) denom 381 = true := by decide

theorem benchmarks :
    rounds totalGain (mass*scale) 2843 = true ∧
    rounds (policyGain - totalGain) (mass*scale) (-983) = true ∧
    rounds ((batches.map Batch.oracle).sum - positive totalGain) (mass*scale) 5904 = true ∧
    positive (totalGain-policyGain) + positive policyGain = positive totalGain := by decide

/-- At each test date both policies train on the same strictly earlier dates.
Each input batch has equal total mass. -/
def walk (burn : Nat) (lookback : Option Nat) : List Int :=
  (List.range (batches.length - burn)).map fun i => Id.run do
    let past := batches.take (burn+i)
    let train := past.drop (past.length - lookback.getD past.length)
    let b := batches[burn+i]!
    let down := (train.map Batch.policy).sum
    let allG := (train.map Batch.late).sum
    let adaptive := choose (decide (0 < down)) b.policy +
                    choose (decide (0 < allG-down)) (b.late-b.policy)
    return adaptive - choose (decide (0 < allG)) b.late

def walkRounds (burn : Nat) (h : Option Nat) (cents : Int) : Bool :=
  let xs := walk burn h
  rounds xs.sum ((xs.length : Int)*common*scale) cents

theorem chronological_checks :
    walkRounds 6 none 631 = true ∧ walkRounds 8 (some 4) (-846) = true ∧
    walkRounds 8 (some 6) (-1311) = true ∧ walkRounds 8 (some 8) 1055 = true ∧
    walkRounds 8 none (-193) = true := by decide

#print axioms attribution
#print axioms independent_pairs
#print axioms information_nonnegative
#print axioms information_zero_iff
#print axioms ledger_checks
#print axioms main_attribution
#print axioms benchmarks
#print axioms chronological_checks
end Timing
