"""Translate the published ledger into exact Lean integer literals."""
import argparse
import csv
import hashlib
import math
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
LEDGER = HERE.parent / "results" / "pairs.csv"
OUTPUT = HERE / "Ledger.lean"
SCALE = 100_000


def units(text):
    value = Decimal(text) * SCALE
    if value != int(value):
        raise ValueError(f"Additional decimal precision in {text}")
    return str(int(value))


def render():
    batches = defaultdict(dict)
    with LEDGER.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            if (row["cost"], row["cohort"]) != ("base", "other_batches"):
                continue
            day, code = row["last_old_session"], row["code"]
            if code in batches[day]:
                raise ValueError(f"Duplicate {day} {code}")
            signal = Decimal(row["close_d"]) < Decimal(row["close_before_d"])
            if int(signal) != int(row["signal_wait"]):
                raise ValueError(f"Inconsistent signal {day} {code}")
            amounts = [units(row[k]) for k in ("fixed_wealth", "always_wait_wealth", "flex_wealth")]
            batches[day][code] = "(" + ", ".join([str(signal).lower(), *amounts]) + ")"
    digest = hashlib.sha256(LEDGER.read_bytes()).hexdigest()
    lines = [f"-- Generated from results/pairs.csv; SHA-256 {digest}.",
             "namespace Timing", "abbrev Row := Bool × Int × Int × Int",
             f"def scale : Int := {SCALE}",
             f"def common : Int := {math.lcm(*(len(b) for b in batches.values()))}",
             "def ledger : List (List Row) := ["]
    blocks = []
    for day, batch in sorted(batches.items()):
        entries = ",\n".join(f"    {batch[code]} /- {code} -/" for code in sorted(batch))
        blocks.append(f"  /- {day} -/ [\n{entries}]")
    return "\n".join(lines) + "\n" + ",\n".join(blocks) + "]\nend Timing\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    source = render()
    if args.check:
        if OUTPUT.read_text(encoding="utf-8") != source:
            raise SystemExit("Ledger.lean differs from the published CSV")
    else:
        OUTPUT.write_text(source, encoding="utf-8")
