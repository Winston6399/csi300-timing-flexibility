"""Generate LaTeX inputs solely from the numerical release."""
import csv
from collections import Counter
from pathlib import Path
from statistics import fmean

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def result(name):
    return read(PROJECT / "results" / (name + ".csv"))


def select(rows, **filters):
    matches = [r for r in rows if all(r[k] == v for k, v in filters.items())]
    if len(matches) != 1:
        raise ValueError(f"Expected one row: {filters}")
    return matches[0]


def fmt(x):
    return f"{float(x):.2f}"


def main():
    events = read(PROJECT / "events.csv") + read(PROJECT / "events_recent.csv")
    counts = Counter(r["last_old_session"] for r in events)
    cohort = "other_batches"
    mainset = result("samples")
    summaries = result("extension_summary")
    def sample(metric, cost="base", group=cohort):
        return select(mainset, cohort=group, contrast=metric, cost=cost)
    def extra(what, metric):
        return select(summaries, cohort=cohort, extension=what, metric=metric)
    def mean(row):
        return fmt(row["equal_batch_mean"])
    a = sample("flex_minus_fixed")
    w = sample("wait_minus_fixed")
    b = select(result("timing_bounds"), cohort=cohort)
    old = extra("funding_old_loss", "prefund_vs_one_day_delay")
    batches = [r for r in result("batches") if r["cost"] == "base"]
    rs = result("market_control_summary")
    diff = extra("placebo", "actual_minus_placebo")
    num_open = sum(int(r["fixed_filled"]) for r in batches)
    audit = result("market_check")
    points = ("d", "d1", "d2", "d5")
    def dual(r):
        return (r.get("primary_provider","").lower() not in ("sohu","") and
                r["status"] not in ("same_source","error") and all(r[k].endswith(":ok") for k in points))
    passed = sum(dual(r) for r in audit)
    audit_errors = sum(r["status"] == "error" for r in audit)
    analysis_pairs = [r for r in result("pairs") if r["cost"] == "base"]
    chronology = []
    for name, rule in (("Earlier", lambda d:d<"2023"),("Later", lambda d:d>="2023")):
        part = [float(r["flex_minus_fixed"]) for r in batches if r["cohort"] == cohort and rule(r["last_old_session"])]
        chronology.append((name, len(part), fmt(fmean(part))))
    vals = dict(First=min(counts), Last=max(counts), Events=len(events), Dates=len(counts),
                Usable=len(analysis_pairs), Rejected=len(events)-len(analysis_pairs),
                MainN=a["pairs"], MainB=a["batches"], Pos=a["positive_batches"], NWait=a["wait_signals"],
                Policy=mean(a), Low=fmt(a["batch_bootstrap_low"]), High=fmt(a["batch_bootstrap_high"]),
                Always=mean(w), AlwaysLow=fmt(w["batch_bootstrap_low"]), AlwaysHigh=fmt(w["batch_bootstrap_high"]),
                VsLate=mean(sample("flex_minus_wait")), Oracle=fmt(b["perfect_information_ceiling"]),
                BestMean=fmt(b["empirical_best_policy_mean"]), NoCost=mean(sample("flex_minus_fixed","zero")),
                HighCost=mean(sample("flex_minus_fixed","stress")),
                Mkt=mean(select(rs, cohort=cohort, metric="adjusted_flex_minus_fixed")),
                MktAlways=mean(select(rs, cohort=cohort, metric="adjusted_wait_minus_fixed")),
                Diff=mean(diff), PlaceboN=diff["pairs"], PlaceboB=diff["batches"],
                AuditN=len(audit), AuditOk=passed, AuditErrors=audit_errors,
                FixedFill=num_open, FullFund=mean(extra("funding_all","prefund_vs_one_day_delay")),
                FullFast=mean(extra("funding_all","prefund_vs_immediate")),
                FullFundB=extra("funding_all","prefund_vs_immediate")["batches"],
                FullFundN=extra("funding_all","prefund_vs_immediate")["pairs"], LossN=old["pairs"],
                LossB=old["batches"], LossSlow=mean(old), LossFast=mean(extra("funding_old_loss","prefund_vs_immediate")),
                EarlyB=chronology[0][1], LateB=chronology[1][1],
                Early=chronology[0][2], Late=chronology[1][2],
                June=mean(sample("flex_minus_fixed",group="explored_2025_06")),
                December=mean(sample("flex_minus_fixed",group="previously_seen_2025_12")))
    info = result("information_summary")
    middle = select(info, burn_in="6")
    att = result("timing_attribution")
    parts = {"calendar":"Mix","between_dates":"Between","within_date":"Within",
             "information_association":"Sort","total":"AttribTotal"}
    for name, macro in parts.items():
        rec = select(att, component=name)
        for col, suffix in (("estimate",""),("low","Lo"),("high","Hi")):
            vals[macro+suffix] = fmt(rec[col])
    vals["MixRate"] = fmt(100*float(select(att,component="delay_rate")["estimate"]))
    vals["GapAbs"] = fmt(abs(float(sample("flex_minus_wait")["equal_batch_mean"])))
    vals["ForwardBase"], vals["ForwardTotal"] = fmt(middle["calendar"]), fmt(middle["total"])
    common = result("common_test_window")
    for rec,label in zip(common,("Four","Six","Eight","All")):
        vals["Same"+label] = fmt(rec["information"])
    vals.update(Forward=fmt(middle["test_increment"]), ForwardN=middle["test_dates"],
                ShortBurn=fmt(select(info,burn_in="4")["test_increment"]),
                LongBurn=fmt(select(info,burn_in="8")["test_increment"]),
                SignalInfo=fmt(middle["pooled_signal_value"]),
                PerfectInfo=fmt(middle["perfect_above_best_fixed"]),
                FixedTest=fmt(middle["gain_vs_best_test_fixed"]),
                Dual=mean(select(result("dual_source_sensitivity"),cohort=cohort)))
    loss_bounds = select(result("funding_bounds"),group="loss",p="0.25")
    vals.update(FundLo=fmt(loss_bounds["lower"]),FundHi=fmt(loss_bounds["upper"]),
                FundInd=fmt(loss_bounds["independent"]),
                Crossing=f"{100*float(loss_bounds['independent_crossing']):.1f}")
    macros = [r"\newcommand{" + chr(92) + k + "}{" + str(v) + "}" for k,v in vals.items()]
    (HERE/"numbers.tex").write_text("\n".join(macros) + "\n", encoding="utf-8")
    lines = []
    for row in sorted(batches,key=lambda r:r["last_old_session"]):
        d = row["last_old_session"]
        lines.append(f"{d} & {counts[d]} & {row['n']} & {row['signal_wait']} & {fmt(row['flex_minus_fixed'])} & {fmt(row['wait_minus_fixed'])}"
                     + r" \\"+"\n")
    (HERE/"batch_rows.tex").write_text("".join(lines),encoding="utf-8")


if __name__ == "__main__":
    main()
